#pragma once
#include "dato.h"

class nodo
{
public:
	dato Dato;
	nodo *puntero;
	nodo(){//constructor de la clase
		puntero= NULL;
	}
	~nodo(void);
};

