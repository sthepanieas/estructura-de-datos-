#pragma once
#include <string>
using namespace std;
class dato
{
public:
	double Codigo;
	string Nombre;
	string Carrera;
	dato(){
		Codigo=0;
		Nombre="Unknown";
		Carrera= "Unknown";
	}
	~dato(void);
};

