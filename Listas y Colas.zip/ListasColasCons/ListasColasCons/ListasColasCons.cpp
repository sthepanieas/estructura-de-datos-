// ListasColasCons.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "nodo.h" //se incluye la clase nodo

using namespace std;

void Encolar(nodo *&inicio,nodo *&fin);
void Desencolar(nodo *&inicio);

void main()
{nodo *inicio=NULL,*fin=NULL;
int opc=0, respuesta=0;
do
{cout<<"1.La cola esta vacia?"<<endl;
cout<<"2.Encolar"<<endl;
cout<<"3.Desencolar"<<endl;
cout<<"OPCION:  "; cin>>opc;
switch (opc)
{case 1:
 if(inicio==NULL)
 {
 cout<<"La cola se encuentra vacia"<<endl;
 }
 else
 {
	 cout<<"Se encuentran elemento(s) en la cola"<<endl;
 }
break;
case 2:
	Encolar(inicio,fin);
	break;
case 3:
	Desencolar(inicio);
}
}while(opc!=4);


}
void Encolar(nodo *&inicio,nodo *&fin)//punteros enviados con referencia
{nodo *Elemento=new nodo;//Creacion del nodo      nodo Elemento;
 if(inicio==NULL)
 {inicio=fin=Elemento;//le asigno la direccion del primer nodo
  cout<<"Codigo: ";cin>>Elemento->Dato.Codigo;
  cout<<"Nombre: ";cin>>Elemento->Dato.Nombre;
  cout<<"Carrera: ";cin>>Elemento->Dato.Carrera;cout<<endl;
 }
 else
 {fin->puntero=Elemento;//Asigno el puntero del anterior elemento al nuevo
  fin= Elemento; //Cambio l adireccion del ultimo nodo creado

  cout<<"Codigo: ";cin>>Elemento->Dato.Codigo;
  cout<<"Nombre: ";cin>>Elemento->Dato.Nombre;
  cout<<"Carrera: ";cin>>Elemento->Dato.Carrera;cout<<endl;
 }
}
void Desencolar(nodo *&inicio)
{if(inicio!=NULL){
	cout<<"Codigo: "<<inicio->Dato.Codigo<<endl;
    cout<<"Nombre: "<<inicio->Dato.Nombre<<endl;
    cout<<"Carrera: "<<inicio->Dato.Carrera<<endl;
	inicio=inicio->puntero;//cambio inicio al siguiente nodo
}
else
{
	cout<<"La cola se encuentra vacia"<<endl;
}
}

