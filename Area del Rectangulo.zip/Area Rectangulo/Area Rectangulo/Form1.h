#pragma once

#include "Rectangulo.h"
#include "iostream"
#include "msclr\marshal_cppstd.h"

namespace AreaRectangulo {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr;
	using namespace msclr::interop;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  lblBase;
	protected: 
	private: System::Windows::Forms::Label^  lblAltura;
	private: System::Windows::Forms::Label^  lblArea;
	private: System::Windows::Forms::TextBox^  txtBase;
	private: System::Windows::Forms::TextBox^  txtAltura;
	private: System::Windows::Forms::TextBox^  txtArea;
	private: System::Windows::Forms::Button^  btnCalcular;
	private: System::Windows::Forms::Button^  btnPerimetro;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->lblBase = (gcnew System::Windows::Forms::Label());
			this->lblAltura = (gcnew System::Windows::Forms::Label());
			this->lblArea = (gcnew System::Windows::Forms::Label());
			this->txtBase = (gcnew System::Windows::Forms::TextBox());
			this->txtAltura = (gcnew System::Windows::Forms::TextBox());
			this->txtArea = (gcnew System::Windows::Forms::TextBox());
			this->btnCalcular = (gcnew System::Windows::Forms::Button());
			this->btnPerimetro = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// lblBase
			// 
			this->lblBase->AutoSize = true;
			this->lblBase->Font = (gcnew System::Drawing::Font(L"Harlow Solid Italic", 16, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->lblBase->Location = System::Drawing::Point(199, 76);
			this->lblBase->Name = L"lblBase";
			this->lblBase->Size = System::Drawing::Size(87, 40);
			this->lblBase->TabIndex = 0;
			this->lblBase->Text = L"Base";
			// 
			// lblAltura
			// 
			this->lblAltura->AutoSize = true;
			this->lblAltura->Font = (gcnew System::Drawing::Font(L"Harlow Solid Italic", 16, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->lblAltura->Location = System::Drawing::Point(199, 152);
			this->lblAltura->Name = L"lblAltura";
			this->lblAltura->Size = System::Drawing::Size(118, 40);
			this->lblAltura->TabIndex = 1;
			this->lblAltura->Text = L"Altura";
			// 
			// lblArea
			// 
			this->lblArea->AutoSize = true;
			this->lblArea->Font = (gcnew System::Drawing::Font(L"Harlow Solid Italic", 16, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->lblArea->Location = System::Drawing::Point(199, 247);
			this->lblArea->Name = L"lblArea";
			this->lblArea->Size = System::Drawing::Size(95, 40);
			this->lblArea->TabIndex = 2;
			this->lblArea->Text = L"Area";
			// 
			// txtBase
			// 
			this->txtBase->Location = System::Drawing::Point(503, 76);
			this->txtBase->Name = L"txtBase";
			this->txtBase->Size = System::Drawing::Size(113, 26);
			this->txtBase->TabIndex = 3;
			// 
			// txtAltura
			// 
			this->txtAltura->Location = System::Drawing::Point(503, 152);
			this->txtAltura->Name = L"txtAltura";
			this->txtAltura->Size = System::Drawing::Size(113, 26);
			this->txtAltura->TabIndex = 4;
			// 
			// txtArea
			// 
			this->txtArea->Location = System::Drawing::Point(503, 247);
			this->txtArea->Name = L"txtArea";
			this->txtArea->Size = System::Drawing::Size(104, 26);
			this->txtArea->TabIndex = 5;
			// 
			// btnCalcular
			// 
			this->btnCalcular->DialogResult = System::Windows::Forms::DialogResult::Ignore;
			this->btnCalcular->Font = (gcnew System::Drawing::Font(L"Harlow Solid Italic", 20, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->btnCalcular->Location = System::Drawing::Point(206, 324);
			this->btnCalcular->Name = L"btnCalcular";
			this->btnCalcular->Size = System::Drawing::Size(209, 60);
			this->btnCalcular->TabIndex = 6;
			this->btnCalcular->Text = L"Calcular";
			this->btnCalcular->UseVisualStyleBackColor = true;
			this->btnCalcular->Click += gcnew System::EventHandler(this, &Form1::btnCalcular_Click);
			// 
			// btnPerimetro
			// 
			this->btnPerimetro->Location = System::Drawing::Point(474, 324);
			this->btnPerimetro->Name = L"btnPerimetro";
			this->btnPerimetro->Size = System::Drawing::Size(142, 60);
			this->btnPerimetro->TabIndex = 7;
			this->btnPerimetro->Text = L"Perimetro";
			this->btnPerimetro->UseVisualStyleBackColor = true;
			this->btnPerimetro->Click += gcnew System::EventHandler(this, &Form1::btnPerimetro_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(9, 20);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(745, 428);
			this->Controls->Add(this->btnPerimetro);
			this->Controls->Add(this->btnCalcular);
			this->Controls->Add(this->txtArea);
			this->Controls->Add(this->txtAltura);
			this->Controls->Add(this->txtBase);
			this->Controls->Add(this->lblArea);
			this->Controls->Add(this->lblAltura);
			this->Controls->Add(this->lblBase);
			this->Name = L"Form1";
			this->Text = L"=--";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

	private: System::Void lblBase_Click(System::Object^  sender, System::EventArgs^  e) {

			 }

	private: System::Void lblAltura_Click(System::Object^  sender, System::EventArgs^  e) {

			 }
	private: System::Void btnCalcular_Click(System::Object^  sender, System::EventArgs^  e) {

				 Rectangulo Rectangulito;
				 Rectangulito.Set_Base(System::Convert::ToInt32(txtBase->Text));
				 Rectangulito.Set_Altura(System::Convert::ToInt32(txtAltura->Text));
				 int Areafin;
				 Areafin=Rectangulito.Calcular();
				 txtArea->Text=System::Convert::ToString(Areafin);
				 // txtArea->Text=System::Convert::ToString(Rectangulito.Calcular()); = Rectangulito.Calcular()
			 }
private: System::Void btnPerimetro_Click(System::Object^  sender, System::EventArgs^  e) {
			 Rectangulo matias;
			 matias.Set_Base(Convert::ToInt32(txtBase->Text));
			 matias.Set_Altura(Convert::ToInt32(txtAltura->Text));
			 txtArea-> Text=Convert::ToString(matias.Perimetro());


		 }
};
}

