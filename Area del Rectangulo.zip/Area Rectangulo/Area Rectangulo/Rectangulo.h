#pragma once
class Rectangulo
{
private: 
	int Base;
	int Altura;
	int Area;
	
public:
	Rectangulo(void);
	int Get_Base();
	int Get_Altura();
	int Get_Area();
	
	

	void Set_Base(int b);
	void Set_Altura(int al);
	void Set_Area(int a);
	

	int Calcular();
	int Perimetro();
	
};

