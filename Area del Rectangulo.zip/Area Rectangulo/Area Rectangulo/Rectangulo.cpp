#include "StdAfx.h"
#include "Rectangulo.h"


Rectangulo::Rectangulo(void)
{
}

int Rectangulo::Get_Base(){
return Base;
}

int Rectangulo::Get_Altura(){
return Altura;
}

int Rectangulo::Get_Area(){
return Area;
}

void Rectangulo::Set_Base(int b){
Base=b;
}

void Rectangulo::Set_Altura(int al){
Altura=al;
}

void Rectangulo::Set_Area(int a){
Area=a;
}

int Rectangulo::Calcular(){
	Area = Base * Altura;
	return Area;
}

int Rectangulo::Perimetro(){
	return (Base*2 + Altura*2);
}

// form quitar mimebro area, renombrar calcular, crear boton guardar