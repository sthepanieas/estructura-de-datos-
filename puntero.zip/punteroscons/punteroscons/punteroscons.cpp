// punteroscons.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include<conio.h>
#include "Nodo.h"
#include <stdlib.h>
using namespace std;
void main()
{Nodo *frente =NULL;
 Nodo *fin =NULL;
 Nodo colita;
 int dato;
 int cont=0;
  do{cout<<"Digite un numero: "<<endl;
  cin>>dato;
  colita.insertarCola(frente,fin,dato);
  cont++;
  }while(cont<5);

	getch();
}

