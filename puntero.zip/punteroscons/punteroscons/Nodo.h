#pragma once
class Nodo
{int dato;
 Nodo *sig;
public:
	Nodo(void);
	~Nodo(void);
	void insertarCola(Nodo *&frente,Nodo *&fin, int n);
	bool cola_vacia(Nodo *frente);
};


