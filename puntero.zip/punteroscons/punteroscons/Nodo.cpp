#include "StdAfx.h"
#include "Nodo.h"
#include <iostream>
using namespace std;

Nodo::Nodo(void)
{
}


Nodo::~Nodo(void)
{
}
void Nodo::insertarCola(Nodo *&frente,Nodo *&fin, int n)
{
	Nodo *nuevo_nodo= new Nodo();
	nuevo_nodo->dato=n;
	nuevo_nodo->sig= NULL;
	if(cola_vacia(frente))
	{frente=nuevo_nodo;
    }
	else
	{fin->sig= nuevo_nodo;
    }
	fin= nuevo_nodo;
	cout<<"Elemento "<<n<<" insertado en la cola correctamente"<<endl;
}
bool Nodo::cola_vacia(Nodo *frente)
{if(frente==NULL)
 {
	 return true;
 }
else
	{
		return false;
    }
}
