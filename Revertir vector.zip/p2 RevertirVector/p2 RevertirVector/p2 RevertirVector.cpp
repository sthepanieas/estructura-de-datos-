// p2 RevertirVector.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "conio.h"
#include "Revertir.h"
#define MAX 100

using namespace std;

int main(){

	int vec[MAX],n;
	Revertir rev;

	cout<<"Ingrese el tamano del vector : ";
	cin>>n;

	rev.CargarVector(vec,n);
	rev.MostrarVector(vec,n);
	rev.RevertirVector(vec,n);

	getch();
return 0;
}
