#pragma once
class Revertir
{
private:
	int vec[100];
	int n;

public:

	Revertir(void);
	~Revertir(void);

	void CargarVector(int vec[], int n);
	void MostrarVector(int vec[], int n);
	void RevertirVector(int vec[], int n);
};

