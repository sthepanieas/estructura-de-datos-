#include "StdAfx.h"
#include <iostream>
#include "Revertir.h"

using namespace std;

Revertir::Revertir(void)
{
	vec[10]=0;
		n=0;
}


Revertir::~Revertir(void)
{
}

void Revertir::CargarVector(int vec[], int n){

	for(int k=0; k<n; k++){
	cout<<"["<<k+1<<"] Cargue el vector : ";
	cin>>vec[k];
	}
}
void Revertir::MostrarVector(int vec[], int n){
	for(int k=0; k<n; k++){
	cout<<"vector ["<<k<<"] : "<<vec[k]<<endl;
	}

}
void Revertir::RevertirVector(int vec[], int n){
	for(int k=0, i=n; k<n, i>=0; k++, i--){
	cout<<"vector invertido ["<<i<<"] : "<<vec[i]<<endl;
	}
}
